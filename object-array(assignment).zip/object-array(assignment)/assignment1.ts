//Object , Array and function
//Assignment 1: Building Your Friend List
const people={
    friends:[]
}
const list1={
    firstName:'Zain',
    lastName:'Malik',
    id:1,
};
const list2={
    firstName:'Ali',
    lastName:'Tasha',
    id:2,
};
const list3={
    firstName:'Robert',
    lastName:'Blue',
    id:3,
};
people.friends.push(list1,list2,list3);
console.log(people);

